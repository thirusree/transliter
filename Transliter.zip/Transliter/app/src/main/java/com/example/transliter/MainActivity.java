package com.example.transliter;

import android.app.Activity;

public class MainActivity extends Activity {
}
